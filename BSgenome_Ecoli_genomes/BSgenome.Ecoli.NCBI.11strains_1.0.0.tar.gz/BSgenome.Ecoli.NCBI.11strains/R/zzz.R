###
###

.pkgname <- "BSgenome.Ecoli.NCBI.11strains"

.seqnames <- c("NC_000913","NC_000913_F","NC_002695","NC_011741","NC_011745","NC_011750","NC_011751","NC_012967","NC_017634","NC_018658","NZ_CP012868")

.circ_seqs <- NULL

.mseqnames <- NULL

.onLoad <- function(libname, pkgname)
{
    if (pkgname != .pkgname)
        stop("package name (", pkgname, ") is not ",
             "the expected name (", .pkgname, ")")
    extdata_dirpath <- system.file("extdata", package=pkgname,
                                   lib.loc=libname, mustWork=TRUE)

    ## Make and export BSgenome object.
    bsgenome <- BSgenome(
        organism="Escherichia coli",
        common_name="escherichia",
        provider="NCBI",
        provider_version="v1",
        release_date="03-NOV-2020",
        release_name="Escherichia coli",
        source_url="https://www.ncbi.nlm.nih.gov/genome/?term=txid562[Organism:exp]",
        seqnames=.seqnames,
        circ_seqs=.circ_seqs,
        mseqnames=.mseqnames,
        seqs_pkgname=pkgname,
        seqs_dirpath=extdata_dirpath
    )

    ns <- asNamespace(pkgname)

    objname <- pkgname
    assign(objname, bsgenome, envir=ns)
    namespaceExport(ns, objname)

    old_objname <- "ecoli"
    assign(old_objname, bsgenome, envir=ns)
    namespaceExport(ns, old_objname)
}

